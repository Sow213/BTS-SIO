<?php
require_once('Controleur/MedicamentController.php');

$medicamentController = new MedicamentController();
$medicamentController->afficherMedicaments();
?>
