<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails de l'activité</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <div class="container">
        <h1>Détails de l'activité</h1>
        <p>Nom de l'activité: Activité 1</p>
        <p>Description de l'activité: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod...</p>
        <!-- Add more details about the activity as needed -->
    </div>
</body>
</html>