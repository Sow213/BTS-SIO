<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des activités</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <div class="container">
        <h1>Liste des activités</h1>
        
        <!-- Place your code here to retrieve and display activities from your data source -->

        <p><a href="activite_details.php">Rejoindre l'activité 1</a></p>
        <p><a href="activite_details.php">Rejoindre l'activité 2</a></p>
        <!-- Add more activity links as needed -->
    </div>
</body>
</html>