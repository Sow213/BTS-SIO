<?php
// Page PHP pour afficher la page
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>La Journée du 10 avril 2025</title>
    <link rel="icon" href="images/favicon.png" type="image/jpeg">
    <link rel="stylesheet" href="style1.css">

    <!-- Menu -->
    <nav>
        <ul style="list-style-type: none; display: flex; justify-content: center; background-color: #2C3E50; padding: 10px;">
            <li><a href="index.php" style="color: white; text-decoration: none; padding: 10px 20px;">Accueil</a></li>
            <li><a href="connexion.php" style="color: white; text-decoration: none; padding: 10px 20px;">Connexion</a></li>
            <li><a href="ateliers.php" style="color: white; text-decoration: none; padding: 10px 20px;">Ateliers</a></li>
            <li><a href="expositions.php" style="color: white; text-decoration: none; padding: 10px 20px;">Expositions</a></li>
        </ul>
    </nav>

</head>

<body>
    <div class="container">
        <h1>La Journée 10 avril 2025</h1>

        <!-- Logo en haut -->
        <div class="logo-container">
            <center>
                <img src="images/logo.jpg" alt="Logo" style="width: 400px; height: auto;">
            </center>
        </div>

        <div class="presentation-section">
            <h2>Présentation</h2>
            <p>En 2014, pour JOUR DE RÊVE, vous étiez plus de soixante à venir de tous horizons.<br>
                En 2018, pour « Sur les traces de 14/18 » vous étiez cinquante.</p>
            <p>Portés par l’expérience de <em>JOUR DE RÊVE</em> (2014) et <em>SUR LES TRACES DE 14/18</em> (2018), 
                les professeurs du lycée Henri Matisse préparent un nouvel événement pour 2025.</p>
            <p><strong>Jeudi 10 avril 2025</strong>, une journée culturelle, associant élèves, enseignants, personnels et intervenants extérieurs, sera organisée. Les élèves pourront :</p>
            <ul>
                <li>Assister à des conférences, rencontrer des professionnels</li>
                <li>Se balader parmi des expositions</li>
                <li>Participer à des ateliers, voir des spectacles, jouer</li>
            </ul>
            <p>* <a href="https://henri-matisse.mon-ent-occitanie.fr/projets-culturels/projet-reve/" target="_blank">Projet Rêve</a><br>
                ** <a href="https://henri-matisse.mon-ent-occitanie.fr/projets-culturels/projet-sur-les-traces-de-14-18/" target="_blank">Projet 14/18</a></p>
        </div>

        <h2>Planning :</h2>
        <p><strong>Cela commencera par :</strong> Une surprise.</p>
        <p><strong>Inscriptions aux ateliers pour :</strong> M1, M2, S1, S2.</p>
        <p><strong>Une activité (Action 1) :</strong> Parcours libre des expositions.</p>
        <p><strong>Fin de journée :</strong> Un bal.</p>

        <h2>Planning détaillé :</h2>
        <table>
            <thead>
                <tr>
                    <th>Créneau</th>
                    <th>Horaire</th>
                    <th>Atelier</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Surprise</td>
                    <td>8h00 - 9h00</td>
                    <td>Surprise de début de journée</td>
                    <td>-</td>
                </tr>
                <tr>
                    <td>M1</td>
                    <td>9h00 - 10h30</td>
                    <td>Atelier 1</td>
                    <td><a href="connexion.php" class="btn">S'inscrire</a></td>
                </tr>
                <tr>
                    <td>M2</td>
                    <td>10h30 - 12h00</td>
                    <td>Atelier 2</td>
                    <td><a href="connexion.php" class="btn">S'inscrire</a></td>
                </tr>
                <tr>
                    <td>S1</td>
                    <td>14h00 - 15h30</td>
                    <td>Atelier 3</td>
                    <td><a href="connexion.php" class="btn">S'inscrire</a></td>
                </tr>
                <tr>
                    <td>S2</td>
                    <td>15h30 - 17h00</td>
                    <td>Atelier 4</td>
                    <td><a href="connexion.php" class="btn">S'inscrire</a></td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-center text-white py-3 mt-5">
        © 2025 La Journée du 10 Avril. Tous droits réservés.
        <p>LYCEE GENERAL ET TECHNOLOGIQUE HENRI MATISSE 
            <br> Adresse : 49 avenue du Comminges 31270 CUGNAUX 
            <br> Téléphone : +33 5 61 72 75 40</p>
    </footer>
</body>

</html>
