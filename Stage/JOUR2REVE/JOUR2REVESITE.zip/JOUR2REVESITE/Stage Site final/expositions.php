<?php 
session_start(); 

// Gestion des informations utilisateur
$prenom = $_SESSION['prenom'] ?? 'Invité';
$nom = $_SESSION['nom'] ?? '';
$type = ($_SESSION['classe'] ?? '') === 'PROF' ? 'prof' : '';

// Connexion à MySQL
include('parametreBDD.php');
if (!isset($bdd)) {
    die("Erreur : Connexion à la base de données non établie.");
}

// Requête pour récupérer les expositions
$requete = "SELECT * FROM actions WHERE type = 'Exposition' ORDER BY numero ASC";
$result = $bdd->query($requete);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Les expositions de la Journée 10 avril 2025</title>
    <link rel="icon" href="images/favicon.png" type="image/jpeg">
    <link rel="stylesheet" href="bootstrap.css">
    <link rel="stylesheet" href="style1.css">

    <style>
        .card {
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        .card-img-top {
            max-height: 200px;
            object-fit: cover;
        }
        .card-body {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .row {
            display: flex;
            flex-wrap: wrap;
        }
        .col-md-6 {
            display: flex;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <!-- Menu -->
    <nav>
        <ul style="list-style-type: none; display: flex; justify-content: center; background-color: #2C3E50; padding: 10px;">
            <li><a href="index.php" style="color: white; text-decoration: none; padding: 10px 20px;">Accueil</a></li>
            <li><a href="connexion.php" style="color: white; text-decoration: none; padding: 10px 20px;">Connexion</a></li>
            <li><a href="ateliers.php" style="color: white; text-decoration: none; padding: 10px 20px;">Ateliers</a></li>
            <li><a href="expositions.php" style="color: white; text-decoration: none; padding: 10px 20px;">Expositions</a></li>
        </ul>
    </nav>

    <!-- Contenu principal -->
    <div class="container mt-5">
        <header class="text-center mb-4">
            <h1 class="display-4" style="font-size: 2rem;">
                <?php if ($nom && $prenom) { ?>
                    Bonjour, <?= htmlspecialchars($prenom . ' ' . $nom); ?>. 
                <?php } ?>
                Découvrez Les expositions de la Journée 10 avril 2025.
            </h1>
        </header>

        <section class="row">
            <?php while ($row = $result->fetch()) { ?>
                <div class="col-md-6">
                    <div class="card">
                        <img src="images/<?= htmlspecialchars($row['numero']); ?>.jpg" class="card-img-top" alt="Image de l'exposition">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($row['numero'] . ' - ' . $row['nom']); ?></h5>
                            <p class="card-text">
                                <strong>Type :</strong> <?= htmlspecialchars($row['type']); ?><br>
                                <strong>Salle :</strong> <?= htmlspecialchars($row['salle']); ?><br>
                                <strong>Places disponibles :</strong> <?= htmlspecialchars($row['M1'] . ' / ' . $row['M2'] . ' / ' . $row['S1'] . ' / ' . $row['S2']); ?><br>
                            </p>
                            <p class="card-text"><?= htmlspecialchars($row['description']); ?></p>
                        </div>
                    </div>
                </div>
            <?php } ?>
            <?php $result->closeCursor(); ?>
        </section>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-center text-white py-3 mt-5">
        © 2025 La Journée du 10 Avril. Tous droits réservés. 
        <p>LYCEE GENERAL ET TECHNOLOGIQUE HENRI MATISSE 
            <br> Adresse : 49 avenue du Comminges 31270 CUGNAUX 
            <br> Téléphone : +33 5 61 72 75 40</p>
    </footer>
    <script src="bootstrap.bundle.min.js"></script>
</body>
</html>
