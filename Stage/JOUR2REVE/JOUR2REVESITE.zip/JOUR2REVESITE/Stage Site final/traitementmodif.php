<?php session_start(); 	
	// Connection à mysql
	include('parametreBDD.php');
	// fin de la partie connexion
	// on récupère les infos
	if ($_SESSION['classe']=='PROF') 
			{
				$nom = $_SESSION['nome'];	
				$prenom = $_SESSION['prenome'];
				$mdp = $_SESSION['mdpe'];
				$type='prof';
			} 
			else 
			{
				$prenom = $_SESSION['prenom'];
				$nom = $_SESSION['nom'];
				$mdp = $_SESSION['mdp'];
				$type='';
			};
	if ($prenom =='' AND $nom =='')
			{header('Location: index.html');}
	$nouveau = htmlspecialchars($_POST['nouveau']);
	$plage = htmlspecialchars($_POST['plage']);
	// on récupère les numeros des actions avant modif
	$requete="SELECT * from eleves WHERE  prenom= '$prenom'  AND nom = '$nom' AND mdp='$mdp'" ; // requête proprement dite 
		$result = $bdd->query($requete); // envoi de la requête 
		$row=$result->fetch(); //le résultat revient sous forme d'une matrice
		$M1=$row['M1'];
		$M2=$row['M2'];
		$S1=$row['S1'];
		$result->closeCursor();
$requete="SELECT * from actions WHERE numero= '$nouveau' ";
$result = $bdd->query($requete);  // envoi de la requête 
$row=$result->fetch(); 
if ((($nouveau==$M1) or ($nouveau==$M2) or ($nouveau==$S1)) and (($nouveau!="0") and ($nouveau!="444")))
	{
		?>
		<h3><?php echo "Desole vous avez deja selectione cette action a une autre plage horaire";?> </h3>
		<li><a href="eleve.php">Ma journee</a></li> <?php 
	}
	ELSE
	{
if ($plage=="M1")
	// test pour voir si c'est plein
	if ($row['occupationM1'] >= $row['nombre']) 
			{
				echo 'Désolé l action numero '.$nouveau.' n est plus disponible';
				?>
				<li><a href="eleve.php">Ma journée</a></li> <?php 
			}
			ELSE
			{
				// enlever la place reserve dans la base action
				$requete2="UPDATE actions SET occupationM1=occupationM1-1 WHERE numero= '$M1' ";
				$result2 =$bdd->query($requete2);  // envoi de la requête
				$result2->closeCursor();
				// modifier la base eleve
				$requete2="UPDATE eleves SET M1='$nouveau' WHERE prenom= '$prenom'  AND nom = '$nom' AND mdp='$mdp'";
				$result2 =$bdd->query($requete2);  // envoi de la requête
				$result2->closeCursor();
				// modifier la base actions
				$requete2="UPDATE actions SET occupationM1=occupationM1+1 WHERE numero= '$nouveau' ";
				$result2 =$bdd->query($requete2);  // envoi de la requête
				$result2->closeCursor();
				// revenir à l affichage eleve
				header('Location: eleve.php');
			}
if ($plage=="M2")
	if ($row['occupationM2'] >= $row['nombre']) 
			{
				echo 'Désolé l action numero '.$nouveau.'n est plus disponible';
				?>
				<li><a href="eleve.php">Ma journée</a></li> <?php 
			}
			ELSE
			{
				// enlever la place reserve dans la base action
				$requete2="UPDATE actions SET occupationM2=occupationM2-1 WHERE numero= '$M2' ";
				$result2 =$bdd->query($requete2);  // envoi de la requête
				$result2->closeCursor();
				// modifier la base eleve
				$requete2="UPDATE eleves SET M2='$nouveau' WHERE prenom= '$prenom'  AND nom = '$nom' AND mdp='$mdp'";
				$result2 =$bdd->query($requete2);  // envoi de la requête
				$result2->closeCursor();
				// modifier la base actions
				$requete2="UPDATE actions SET occupationM2=occupationM2+1 WHERE numero= '$nouveau' ";
				$result2 =$bdd->query($requete2);  // envoi de la requête
				$result2->closeCursor();
				// revenir à l affichage eleve
				header('Location: eleve.php');
			}			
if ($plage=="S1")
	if ($row['occupationS1'] >= $row['nombre']) 
			{
				echo 'Désolé l action numero '.$nouveau.'n est plus disponible';
				?>
				<li><a href="eleve.php">Ma journée</a></li> <?php  
			}
			ELSE
			{
				// enlever la place reserve dans la base action
				$requete2="UPDATE actions SET occupationS1=occupationS1-1 WHERE numero= '$S1' ";
				$result2 =$bdd->query($requete2);  // envoi de la requête
				$result2->closeCursor();
				// modifier la base eleve
				$requete2="UPDATE eleves SET S1='$nouveau' WHERE prenom= '$prenom'  AND nom = '$nom' AND mdp='$mdp'";
				$result2 =$bdd->query($requete2);  // envoi de la requête
				$result2->closeCursor();
				// modifier la base actions
				$requete2="UPDATE actions SET occupationS1=occupationS1+1 WHERE numero= '$nouveau' ";
				$result2 =$bdd->query($requete2);  // envoi de la requête
				$result2->closeCursor();
				// revenir à l affichage eleve
				header('Location: eleve.php');
			}
	}
$result->closeCursor();
?>

    <!-- Footer -->
    <footer class="bg-dark text-center text-white py-3 mt-5">
        © 2025 La Journée du 10 Avril. Tous droits réservés.
        <p>LYCEE GENERAL ET TECHNOLOGIQUE HENRI MATISSE 
            <br> Adresse : 49 avenue du Comminges 31270 CUGNAUX 
            <br> Téléphone : +33 5 61 72 75 40</p>
    </footer>
</body>

</html>