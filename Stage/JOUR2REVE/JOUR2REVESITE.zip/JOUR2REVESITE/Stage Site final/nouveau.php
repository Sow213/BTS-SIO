<?php 
session_start();

// Vérification de l'accès
if ($_SESSION['classe'] == 'PROF') {
    $nom = $_SESSION['nom'];    
    $prenom = $_SESSION['prenom'];
    $type = 'prof';        
} else {
    header('Location: Index.html');
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8" />
    <title>La Journée du 10 avril 2025</title>
    <link rel="icon" href="images/favicon.png" type="image/jpeg">
    <meta http-equiv="content-language" content="fr" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" type="text/css" href="style2.css">

     <!-- Menu -->
    <nav>
        <ul style="list-style-type: none; display: flex; justify-content: center; background-color: #2C3E50; padding: 10px;">
            <li><a href="index.php" style="color: white; text-decoration: none; padding: 10px 20px;">Accueil</a></li>
            <li><a href="connexion.php" style="color: white; text-decoration: none; padding: 10px 20px;">Connexion</a></li>
            <li><a href="ateliers.php" style="color: white; text-decoration: none; padding: 10px 20px;">Ateliers</a></li>
            <li><a href="expositions.php" style="color: white; text-decoration: none; padding: 10px 20px;">Expositions</a></li>
            <li><a href="prof.php" style="color: white; text-decoration: none; padding: 10px 20px;">Page d'accueil professeur</a></li>

                        
        </ul>
    </nav>
    <style>
        /* Style pour aligner les champs */
        table {
            width: 50%;
            margin: auto;
            border-collapse: collapse;
        }
        td {
            padding: 8px;
            text-align: left;
        }
        input, select {
            width: 100%;
            padding: 5px;
        }
        .submit-btn {
            text-align: center;
        }
    </style>
</head>
<body>

<div id="bloc_page">
    <header>
        <h1>Bonjour Professeur <?php echo htmlspecialchars($prenom . ' ' . $nom); ?></h1>
        
    </header>

    <section>
        <br><br>
        <form method="post" action="traitementnouveau.php">
            <table>
                <tr>
                    <td>Password Admin (pour crée élève):</td>
                    <td><input type="password" name="mdpe" required /></td>
                </tr>
                <tr>
                    <td>Nom :</td>
                    <td><input type="text" name="nome" required /></td>
                </tr>
                <tr>
                    <td>Prénom :</td>
                    <td><input type="text" name="prenome" required /></td>
                </tr>
                <tr>
                    <td>Classe :</td>
                    <td>
                        <select name="classe">
                            <?php include('listeclasse.php'); ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Login :</td>
                    <td><input type="text" name="login" placeholder="6 premières lettres du nom et 1ère lettre du prénom" required /></td>
                </tr>
                <tr>
                    <td>Mot de passe :</td>
                    <td><input type="text" name="mdp" placeholder="Minimum 6 lettres" required /></td>
                </tr>
                <tr>
                    <td colspan="2" class="submit-btn">
                        <input type="hidden" name="nom" value="<?php echo htmlspecialchars($nom); ?>" />
                        <input type="hidden" name="prenom" value="<?php echo htmlspecialchars($prenom); ?>" />
                        <input type="submit" value="CRÉER" />
                    </td>
                </tr>
            </table>
        </form>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-center text-white py-3 mt-5">
        © 2025 La Journée du 10 Avril. Tous droits réservés.
        <p>LYCEE GENERAL ET TECHNOLOGIQUE HENRI MATISSE 
            <br> Adresse : 49 avenue du Comminges 31270 CUGNAUX 
            <br> Téléphone : +33 5 61 72 75 40</p>
    </footer>
</div>

</body>
</html>
