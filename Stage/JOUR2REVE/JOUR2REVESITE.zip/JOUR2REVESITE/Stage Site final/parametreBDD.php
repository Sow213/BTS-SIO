<?php
$host_name = 'localhost'; 
$database = 'hma31www';
$user_name = 'root';
$password = '';

try {
   
    $bdd = new PDO("mysql:host=$host_name;dbname=$database;", $user_name, $password);
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Mode d'erreur PDO
    $bdd->exec("SET NAMES 'UTF8'"); 
} catch (PDOException $e) {
   
    echo "Erreur de connexion à la base de données : " . $e->getMessage();
    die();
}

