<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
	<meta http-equiv="content-language" content="fr" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />  
    <title>La Journée du 10 avril 2025</title>
    <link rel="icon" href="images/favicon.png" type="image/jpeg">
	<link rel="stylesheet" type="text/css" href="style2.css" />	
</head>

</head>
<header>
</header>
<body>
	<! c'est l'entête>
	<div id="bloc_page">
		<table>
				<tr>
					<td >		
					<h1>  PUISQU'ON VOUS DIT QUE C'EST UNE SURPRISE </h1>
					</td>		
				</tr>
			</table>
			<header>
			<! c'est une barre de navigation>
			<nav>
					<ul>
						<li><a href="index.php">Retour</a></li> 
					</ul>
			</nav>	
		</header>
	</div>

	    <!-- Footer -->
	    <center>
    <footer class="bg-dark text-center text-white py-3 mt-5">
		© 2025 La Journée du 10 Avril. Tous droits réservés. 
        <p>LYCEE GENERAL ET TECHNOLOGIQUE HENRI MATISSE 
            <br> Adresse : 49 avenue du Comminges 31270 CUGNAUX 
            <br> Téléphone : +33 5 61 72 75 40</p>

</footer>
</center>
</body>
</html>
