<?php
session_start();  
// On récupère les données du formulaire
if ($_SESSION['classe'] == 'PROF') {
    $nom = $_SESSION['nom'];    
    $prenom = $_SESSION['prenom'];
    $type = 'prof';        
} else {
    header('Location: index.html');
}
$classe = $_POST['classe'];

// Connexion à MySQL
include('parametreBDD.php');

// On récupère les éléments de la classe
$requete = "SELECT * from eleves WHERE classe = '$classe'";
$result = $bdd->query($requete); 
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8" />
    <title>La Journée du 10 avril 2025</title>
    <link rel="icon" href="images/favicon.png" type="image/jpeg">
    <meta http-equiv="content-language" content="fr" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />  
    <link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
    <div id="bloc_page">
        <header>
            <h1>Bonjour professeur <?php echo $prenom.' '.$nom; ?></h1>
            <!-- Menu -->
            <nav>
                <ul style="list-style-type: none; display: flex; justify-content: center; background-color: #2C3E50; padding: 10px;">
                    <li><a href="index.php" style="color: white; text-decoration: none; padding: 10px 20px;">Accueil</a></li>
                    <li><a href="connexion.php" style="color: white; text-decoration: none; padding: 10px 20px;">Connexion</a></li>
                    <li><a href="ateliers.php" style="color: white; text-decoration: none; padding: 10px 20px;">Ateliers</a></li>
                    <li><a href="expositions.php" style="color: white; text-decoration: none; padding: 10px 20px;">Expositions</a></li>
                    <li><a href="prof.php" style="color: white; text-decoration: none; padding: 10px 20px;">Page d'accueil professeur</a></li>
                </ul>
            </nav>  
        </header>

        <section>
            <h2>Voici les choix des élèves de la classe <?php echo $classe; ?></h2>

            <p>Selectionner une autre classe: </p>
            <form method="post" name="nouvelle_action" action="fiche_eleve.php">
                <select name="classe">
                    <?php include('listeclasse.php'); ?>
                </select>
                <input type="submit" value="Valider"/>
            </form>

            <!-- Tableau des élèves -->
            <table border="1" cellspacing="0" cellpadding="5">
                <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Prénom</th>
                        <th>Activité M1</th>
                        <th>Activité M2</th>
                        <th>Activité S1</th>
                        <th>Activité S2</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch()) { 
                        $M1 = $row['M1'];
                        $M2 = $row['M2'];
                        $S1 = $row['S1'];
                        $S2 = $row['S2'];

                        // Récupérer les données des actions
                        $requete2 = "SELECT * from actions WHERE numero = '$M1'";
                        $result2 = $bdd->query($requete2);
                        $row2 = $result2->fetch();
                        $nom_M1 = $row2['nom'];
                        $salle_M1 = $row2['salle'];

                        $requete2 = "SELECT * from actions WHERE numero = '$M2'";
                        $result2 = $bdd->query($requete2);
                        $row2 = $result2->fetch();
                        $nom_M2 = $row2['nom'];
                        $salle_M2 = $row2['salle'];

                        $requete2 = "SELECT * from actions WHERE numero = '$S1'";
                        $result2 = $bdd->query($requete2);
                        $row2 = $result2->fetch();
                        $nom_S1 = $row2['nom'];
                        $salle_S1 = $row2['salle'];

                        $requete2 = "SELECT * from actions WHERE numero = '$S2'"; // Récupérer les données pour S2
                        $result2 = $bdd->query($requete2);
                        $row2 = $result2->fetch();
                        $nom_S2 = $row2['nom'];
                        $salle_S2 = $row2['salle'];
                    ?>
                    <tr>
                        <td><?php echo $row['nom']; ?></td>
                        <td><?php echo $row['prenom']; ?></td>
                        <td><?php echo $nom_M1 . ' (Salle: ' . $salle_M1 . ')'; ?></td>
                        <td><?php echo $nom_M2 . ' (Salle: ' . $salle_M2 . ')'; ?></td>
                        <td><?php echo $nom_S1 . ' (Salle: ' . $salle_S1 . ')'; ?></td>
                        <td><?php echo $nom_S2 . ' (Salle: ' . $salle_S2 . ')'; ?></td>
                    </tr>
                    <?php } 
                    $result->closeCursor();
                    ?>
                </tbody>
            </table>
        </section>

        <!-- Footer -->
        <footer class="bg-dark text-center text-white py-3 mt-5">
            © 2025 La Journée du 10 Avril. Tous droits réservés.
            <p>LYCEE GENERAL ET TECHNOLOGIQUE HENRI MATISSE 
                <br> Adresse : 49 avenue du Comminges 31270 CUGNAUX 
                <br> Téléphone : +33 5 61 72 75 40</p>
        </footer>
    </div>
</body>
</html>
