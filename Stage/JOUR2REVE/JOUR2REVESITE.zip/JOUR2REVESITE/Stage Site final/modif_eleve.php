<?php session_start(); 	
	if ($_SESSION['classe']=='PROF') 
			{
				$_SESSION['nome'] = $_POST['nome'];
				$_SESSION['prenome'] = $_POST['prenome'];
				$_SESSION['mdpe'] = $_POST['mdpe'];
				header('Location: eleve.php');		
			} 
			else 
			{
				header('Location: Index.html');
			}
	?>