<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="content-language" content="fr" />
    <title>La Journée du 10 Avril</title>
    <link rel="icon" href="images/favicon.png" type="image/jpeg">
    <link rel="stylesheet" type="text/css" href="style2.css">

        <!-- Menu -->
    <nav>
        <ul style="list-style-type: none; display: flex; justify-content: center; background-color: #2C3E50; padding: 10px;">
            <li><a href="index.php" style="color: white; text-decoration: none; padding: 10px 20px;">Accueil</a></li>
        	<li><a href="connexion.php" style="color: white; text-decoration: none; padding: 10px 20px;">Connexion</a></li>
            <li><a href="ateliers.php" style="color: white; text-decoration: none; padding: 10px 20px;">Ateliers</a></li>
            <li><a href="expositions.php" style="color: white; text-decoration: none; padding: 10px 20px;">Expositions</a></li>
        </ul>
    </nav>
    <?php 
    // Connection à MySQL
    include('parametreBDD.php');
    // Requête SQL
    $requete = "SELECT * FROM actions WHERE numero = '48'";    
    $result = $bdd->query($requete);
    ?>
</head>

<body>
    <div id="bloc_page">
        <!-- Header avec navigation -->
        <header>
            <nav>
                <ul>
                    <li><a href="descriptif.php">Retour</a></li> 
                </ul>
            </nav>
        </header>
        
        <!-- Corps de la page -->
        <section>
            <p>Pour clôturer la journée :</p>
            <?php while ($row = $result->fetch()) { ?>
            <table>
                <tr>
                    <td class="titre" colspan="2">
                        <h1><?php echo $row['numero'] . ' ' . $row['nom']; ?></h1>
                    </td>        
                </tr>
                <tr>
                    <td>
                        <p>
                            <img src="images/<?php echo $row['numero']; ?>.jpg" class="imageflottante" />
                        </p>
                    </td>
                    <td>
                        <p>
                            <?php echo $row['description']; ?>
                        </p>
                    </td>
                </tr>
            </table>
            <?php }
            $result->closeCursor();
            ?>
        </section>
        
        <!-- Footer -->
        <footer class="bg-dark text-center text-white py-3 mt-5">
            © 2025 La Journée du 10 Avril. Tous droits réservés.
            <p>LYCÉE GÉNÉRAL ET TECHNOLOGIQUE HENRI MATISSE 
                <br> Adresse : 49 avenue du Comminges 31270 CUGNAUX 
                <br> Téléphone : +33 5 61 72 75 40
            </p>
        </footer>
    </div>
</body>
</html>
