<?php
session_start();  
// On récupère les données du formulaire
if ($_SESSION['classe'] == 'PROF') {
    $nom = $_SESSION['nom'];    
    $prenom = $_SESSION['prenom'];
    $type = 'prof';        
} else {
    header('Location: index.html');
}
$classe = $_POST['classe'];

// Connexion à MySQL
include('parametreBDD.php');

// On récupère les éléments de la classe
$requete = "SELECT * from eleves WHERE classe = '$classe'";
$result = $bdd->query($requete); 
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8" />
    <title>La Journée du 10 avril 2025</title>
    <link rel="icon" href="images/favicon.png" type="image/jpeg">
    <meta http-equiv="content-language" content="fr" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />  
    <link rel="stylesheet" type="text/css" href="style1.css">
    <link rel="stylesheet" href="bootstrap.css">
    <style>
        /* Masque tout le reste lors de l'impression */
        @media print {
            body * {
                visibility: hidden;
            }
            #printSection, #printSection * {
                visibility: visible;
            }
            #printSection {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
            }

            /* TAILLE TABLEAU POUR IMPRESSION */
            table {
                font-size: 15px; /* Réduit la taille de la police pour l'impression */
            }
            th, td {
                padding: 2px; /* Réduit l'espace à l'intérieur des cellules */
            }
        }
    </style>
</head>
<body>
    <div id="bloc_page">
        <header>
            <h1 style="text-align: center;">Bonjour, Professeur <?php echo htmlspecialchars($prenom . ' ' . $nom); ?></h1>
        </header>

        <nav>
            <ul style="list-style-type: none; display: flex; justify-content: center; background-color: #2C3E50; padding: 10px;">
                <li><a href="index.php" style="color: white; text-decoration: none; padding: 10px 20px;">Accueil</a></li>
                <li><a href="connexion.php" style="color: white; text-decoration: none; padding: 10px 20px;">Connexion</a></li>
                <li><a href="ateliers.php" style="color: white; text-decoration: none; padding: 10px 20px;">Ateliers</a></li>
                <li><a href="expositions.php" style="color: white; text-decoration: none; padding: 10px 20px;">Expositions</a></li>
                <li><a href="prof.php" style="color: white; text-decoration: none; padding: 10px 20px;">Page d'accueil professeur</a></li>
            </ul>
        </nav>

        <main class="container mt-4">
            <h1 class="mb-4 text-center">Voici les choix des élèves de la classe <?php echo htmlspecialchars($classe); ?></h1>

            <section class="mb-4">
                <p>Sélectionner une autre classe :</p>
                <form method="post" action="classe.php">
                    <select name="classe" class="form-select mb-2">
                        <?php include('listeclasse.php'); ?>
                    </select>
                    <button type="submit" class="btn btn-primary">Valider</button>
                </form>
            </section>

            <!-- Section à imprimer -->
            <section id="printSection" class="mt-5">
                <table class="table table-bordered table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>Nom</th>
                            <th>Prénom</th>
                            <th>Activité M1</th>
                            <th>Activité M2</th>
                            <th>Activité S1</th>
                            <th>Activité S2</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch()) { 
                            $M1 = $row['M1'];
                            $M2 = $row['M2'];
                            $S1 = $row['S1'];
                            $S2 = $row['S2'];

                            // Récupérer les données des actions
                            $requete2 = "SELECT * from actions WHERE numero = '$M1'";
                            $result2 = $bdd->query($requete2);
                            $row2 = $result2->fetch();
                            $nom_M1 = $row2['nom'];
                            $salle_M1 = $row2['salle'];

                            $requete2 = "SELECT * from actions WHERE numero = '$M2'";
                            $result2 = $bdd->query($requete2);
                            $row2 = $result2->fetch();
                            $nom_M2 = $row2['nom'];
                            $salle_M2 = $row2['salle'];

                            $requete2 = "SELECT * from actions WHERE numero = '$S1'";
                            $result2 = $bdd->query($requete2);
                            $row2 = $result2->fetch();
                            $nom_S1 = $row2['nom'];
                            $salle_S1 = $row2['salle'];

                            $requete2 = "SELECT * from actions WHERE numero = '$S2'";
                            $result2 = $bdd->query($requete2);
                            $row2 = $result2->fetch();
                            $nom_S2 = $row2['nom'];
                            $salle_S2 = $row2['salle'];
                        ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['nom']); ?></td>
                            <td><?php echo htmlspecialchars($row['prenom']); ?></td>
                            <td><?php echo htmlspecialchars($nom_M1) . ' (Salle: ' . htmlspecialchars($salle_M1) . ')'; ?></td>
                            <td><?php echo htmlspecialchars($nom_M2) . ' (Salle: ' . htmlspecialchars($salle_M2) . ')'; ?></td>
                            <td><?php echo htmlspecialchars($nom_S1) . ' (Salle: ' . htmlspecialchars($salle_S1) . ')'; ?></td>
                            <td><?php echo htmlspecialchars($nom_S2) . ' (Salle: ' . htmlspecialchars($salle_S2) . ')'; ?></td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </section>

            <div class="text-end mt-3">
                <button class="btn btn-success" onclick="printTable()">Imprimer la liste</button>
            </div>
        </main>
    </div>

    <script>
        function printTable() {
            window.print();
        }
    </script>
</body>
</html>
