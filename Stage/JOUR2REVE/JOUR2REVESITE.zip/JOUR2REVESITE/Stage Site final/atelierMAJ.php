<?php 
			include('parametreBDD.php');
			$nombremaj=0;
			$requete="SELECT * from actions ORDER BY numero";	
			$result = $bdd->query($requete);// envoi de la requête
			while ($row2=$result->fetch())
			{ 
				$nom_atelier=$row2['nom'];
				$M1=$row2['M1'];$M2=$row2['M2'];$S1=$row2['S1'];$S2=$row2['S2'];
				$nombre=$row2['nombre'];
				$occupationM1=$row2['occupationM1'];
				$occupationM2=$row2['occupationM2'];
				$occupationS1=$row2['occupationS1'];
				$occupationS2=$row2['occupationS2'];
				$numero2=$row2['numero'];
				if ($M1=='M1')
					{ // on recupere les eleves inscrits en M1 a toutes les actions $numero2 
						$requete2="SELECT * from eleves WHERE M1=$numero2"; // requête proprement dite 
						$result2 = $bdd->query($requete2); // envoi de la requête
						$i=0;
						while ($row3=$result2->fetch())
							{
								$i=$i+1; 
							}
						$result2->closeCursor();
						if ($i!=$occupationM1) 
							{
								$nombremaj=$nombremaj+1;
								// modifier la base actions
								$requete3="UPDATE actions SET occupationM1='$i' WHERE numero= '$numero2' ";
								$result3 =$bdd->query($requete3); // envoi de la requête
								$result3->closeCursor();
							}  
					} 
				if ($M2=='M2')
					{ // on recupere les eleves inscrits en M2 a toutes les actions $numero2 
						$requete2="SELECT * from eleves WHERE M2=$numero2"; // requête proprement dite 
						$result2 = $bdd->query($requete2); // envoi de la requête
						$i=0;
						while ($row3=$result2->fetch())
							{
								$i=$i+1; 
							}
						$result2->closeCursor();				
						if ($i!=$occupationM2) 
							{
								$nombremaj=$nombremaj+100;
								// modifier la base actions
								$requete3="UPDATE actions SET occupationM2='$i' WHERE numero= '$numero2' ";
								$result3 =$bdd->query($requete3); // envoi de la requête
								$result3->closeCursor();
							}  
					} 
				if ($S1=='S1')
					{ // on recupere les eleves inscrits en S1 a toutes les actions $numero2 
						$requete2="SELECT * from eleves WHERE S1=$numero2"; // requête proprement dite 
						$result2 = $bdd->query($requete2); // envoi de la requête
						$i=0;
						while ($row3=$result2->fetch())
							{
								$i=$i+1; 
							}			
						if ($i!=$occupationS1) 
							{
								$nombremaj=$nombremaj+10000;
								// modifier la base actions
								$requete3="UPDATE actions SET occupationS1='$i' WHERE numero= '$numero2' ";
								$result3 =$bdd->query($requete3); // envoi de la requête
								$result3->closeCursor();
							}  
					}  
			}
			$result->closeCursor();
		echo $nombremaj.' inscriptions d\'élèves ont été mis à jours';
		?>
		<html>
<head>
 	<meta charset="utf-8" />
    <title>La Journée du 10 avril 2025</title>
    <link rel="icon" href="images/logo.jpg" type="image/jpeg">
	<meta http-equiv="content-language" content="fr" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />  
	<!--[if IE]><link rel="shortcut icon" type="image/x-icon" href="favicon.ico" /><![endif]-->
	<link rel="stylesheet" type="text/css" href="style6.css">
</head>
<body>
	<! c'est l'entête>
	<div id="bloc_page">
		<header>
		<h1> bonjour professeur <?php echo $prenom.' '.$nom; ?> </h1>
			<! c'est une barre de navigation>
			<nav>
					<ul>
						<li><a href=" <?php echo 'prof.php?nom='.$nom.'&prenom='.$prenom ?>">Page d'accueil professeur</a></li>
											
					</ul>
			</nav>	
		</header>
