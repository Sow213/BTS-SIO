<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Site en cours de création</title>
    <link rel="icon" href="images/favicon.png" type="image/jpeg">

    <link rel="stylesheet" href="style2.css"> <!-- Lien vers un fichier CSS externe pour styliser la page -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            text-align: center;
        }
        h1 {
            font-size: 2.5rem;
            margin-bottom: 20px;
        }
        p {
            font-size: 1.2rem;
            margin-bottom: 30px;
        }
        .button {
            display: inline-block;
            padding: 10px 20px;
            font-size: 1rem;
            color: #fff;
            background-color: #007BFF;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .button:hover {
            background-color: #0056b3;
        }
        footer {
            position: absolute;
            bottom: 10px;
            font-size: 0.9rem;
            color: #666;
        }
    </style>
</head>
<body>
    <h1>Site en cours de création</h1>
    <p>Notre site est actuellement en développement. Pour le moment, vous pouvez uniquement consulter les informations disponibles. Les fonctionnalités de connexion et d'inscription seront bientôt disponibles.</p>
    <a href="index.php" class="button">Voir le contenu</a>
    <!-- Footer -->
    <footer class="bg-dark text-center text-white py-3 mt-5">
        © 2025 La Journée du 10 Avril. Tous droits réservés. 
        <p>LYCEE GENERAL ET TECHNOLOGIQUE HENRI MATISSE 
            <br> Adresse : 49 avenue du Comminges 31270 CUGNAUX 
            <br> Téléphone : +33 5 61 72 75 40</p>
    </footer>
</body>
</html>
