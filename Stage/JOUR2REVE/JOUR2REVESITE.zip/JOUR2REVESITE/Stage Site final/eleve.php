<?php 
session_start();

// Vérification de la connexion
if (empty($_SESSION['prenom']) || empty($_SESSION['nom'])) {
    header('Location: index.php');
    exit;
}

// Récupération des données utilisateur
$prenom = $_SESSION['prenom'];
$nom = $_SESSION['nom'];
$mdp = $_SESSION['mdp'];
$type = $_SESSION['classe'] === 'PROF' ? 'prof' : '';

// Connexion à la base de données
include('parametreBDD.php');

// Récupération des données de l'élève
$requete = $bdd->prepare("SELECT M1, M2, S1, S2 FROM eleves WHERE prenom = ? AND nom = ? AND mdp = ?");
$requete->execute([$prenom, $nom, $mdp]);
$row = $requete->fetch();
$M1 = $row['M1'];
$M2 = $row['M2'];
$S1 = $row['S1'];
$S2 = $row['S2'];
$requete->closeCursor();

// Fonction pour récupérer les informations d'une activité
function getActivityDetails($bdd, $numero) {
    $requete = $bdd->prepare("SELECT nom, salle FROM actions WHERE numero = ?");
    $requete->execute([$numero]);
    $result = $requete->fetch();
    $requete->closeCursor();
    return $result;
}

$activity_M1 = getActivityDetails($bdd, $M1);
$activity_M2 = getActivityDetails($bdd, $M2);
$activity_S1 = getActivityDetails($bdd, $S1);
$activity_S2 = getActivityDetails($bdd, $S2);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <title>La Journée du 10 avril 2025</title>
    <link rel="icon" href="images/favicon.png" type="image/jpeg">
    <link rel="stylesheet" type="text/css" href="style2.css">

     <!-- Menu -->
    <nav>
        <ul style="list-style-type: none; display: flex; justify-content: center; background-color: #2C3E50; padding: 10px;">
            <li><a href="index.php" style="color: white; text-decoration: none; padding: 10px 20px;">Accueil</a></li>
            <li><a href="connexion.php" style="color: white; text-decoration: none; padding: 10px 20px;">Connexion</a></li>
            <li><a href="ateliers.php" style="color: white; text-decoration: none; padding: 10px 20px;">Ateliers</a></li>
            <li><a href="expositions.php" style="color: white; text-decoration: none; padding: 10px 20px;">Expositions</a></li>
            <li><a href="prof.php" style="color: white; text-decoration: none; padding: 10px 20px;">Page d'accueil professeur</a></li>

                        
        </ul>
    </nav>
</head>
<body>
    <div id="bloc_page">
        <header>
            <?php if ($type === "prof"): ?>
                <h1>Bonjour <?php echo htmlspecialchars($_SESSION['prenom']) . ' ' . htmlspecialchars($_SESSION['nom']); ?></h1>
                <h1>Voici la page de <?php echo htmlspecialchars($prenom) . ' ' . htmlspecialchars($nom); ?></h1>
            <?php else: ?>
                <h1>Bonjour <?php echo htmlspecialchars($prenom) . ' ' . htmlspecialchars($nom); ?></h1>
            <?php endif; ?>

            <nav>
                <ul>
                    <?php if ($type === "prof"): ?>
                        <li><a href="prof.php">Page Professeur</a></li>
                    <?php else: ?>
                        <li><a href="deconnexion.php">Déconnexion</a></li>
                        <li><a href="descriptif.php">Descriptif</a></li>
                    
                    <?php endif; ?>
                </ul>
            </nav>
            <h1>Mon programme de la journée</h1>
            <h3>Chaque élève doit s'inscrire aux ateliers proposés sur <strong>4 créneaux</strong> : M1, M2, S1, et S2.</h3>
        </header>

        <section>
            <table>
                <tr>
                    <td class="ligne2">De 8h à 9h</td>
                    <td class="ligne2" colspan="3">
                        <h2>Accueil Surprise</h2>
                    </td>
                </tr>
                <tr>
                    <td class="colon1">
                        <h2>Mon activité en M1</h2>
                        <p>De 9h à 10h30</p>
                    </td>
                    <td><?php echo htmlspecialchars($activity_M1['nom']); ?></td>
                    <td>En salle : <?php echo htmlspecialchars($activity_M1['salle']); ?></td>
                    <td><a href="modifier.php?plage=M1">Modifier</a></td>
                </tr>
                <tr>
                    <td class="colon1">
                        <h2>Mon activité en M2</h2>
                        <p>De 10h30 à 12h</p>
                    </td>
                    <td><?php echo htmlspecialchars($activity_M2['nom']); ?></td>
                    <td>En salle : <?php echo htmlspecialchars($activity_M2['salle']); ?></td>
                    <td><a href="modifier.php?plage=M2">Modifier</a></td>
                </tr>
                <tr>
                    <td class="colon1">
                        <h2>Mon activité en S1</h2>
                        <p>De 14h à 15h30</p>
                    </td>
                    <td><?php echo htmlspecialchars($activity_S1['nom']); ?></td>
                    <td>En salle : <?php echo htmlspecialchars($activity_S1['salle']); ?></td>
                    <td><a href="modifier.php?plage=S1">Modifier</a></td>
                </tr>
                <tr>
                    <td class="colon1">
                        <h2>Mon activité en S2</h2>
                        <p>De 15h30 à 17h</p>
                    </td>
                    <td><?php echo htmlspecialchars($activity_S2['nom']); ?></td>
                    <td>En salle : <?php echo htmlspecialchars($activity_S2['salle']); ?></td>
                    <td><a href="modifier.php?plage=S2">Modifier</a></td>
                </tr>
                <tr>
                    </td>
                </tr>
            </table>
        </section>
    </div>

    <footer>
        <p>© 2025 La Journée du 10 Avril. Tous droits réservés.</p>
        <p>LYCÉE HENRI MATISSE<br>Adresse : 49 avenue du Comminges 31270 CUGNAUX<br>Téléphone : +33 5 61 72 75 40</p>
    </footer>
</body>
</html>
