<?php session_start();  
		header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
		header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date dans le passé
		// on récupère les données de connexion
		if ($_SESSION['classe']=='PROF') 
			{
				$nomp = $_SESSION['nom'];
				$prenomp = $_SESSION['prenom'];
				$nom = $_SESSION['nome'];	
				$prenom = $_SESSION['prenome'];
				$mdp = $_SESSION['mdpe'];
				$type='prof';		
			} 
			else 
			{
				$prenom = $_SESSION['prenom'];
				$nom = $_SESSION['nom'];
				$mdp = $_SESSION['mdp'];
				$type='';
			};
		if ($prenom =='' AND $nom =='')
			{header('Location: index.php');}
		$plage = $_GET['plage'];
		//On récupère les données de l'élève à partir de ses noms et prenoms
		// Connection à mysql
		include('parametreBDD.php');
		// mettre a jour les effectifs des ateliers
		include('atelierMAJ.php');
		// fin de la partie connexion
		$requete="SELECT * from eleves WHERE  prenom= '$prenom'  AND nom = '$nom' AND mdp='$mdp' " ; // requête proprement dite 
		$result = $bdd->query($requete); // envoi de la requête 
		$row=$result->fetch(); //le résultat revient sous forme d'une matrice
		$M1=$row['M1'];
		$M2=$row['M2'];
		$S1=$row['S1'];
		$S2=$row['S2'];
		$result->closeCursor();
		//On récupère les données des actions 
		$requete="SELECT * from actions WHERE  numero= '$M1'"; // requête proprement dite 
		$result =$bdd->query($requete); // envoi de la requête 
		$row=$result->fetch(); //le résultat revient sous forme d'une matrice
		$nom_M1=$row['nom'];
		$result->closeCursor();
		$requete="SELECT * from actions WHERE  numero= '$M2'"; // requête proprement dite 
		$result =$bdd->query($requete); // envoi de la requête 
		$row=$result->fetch(); //le résultat revient sous forme d'une matrice
		$nom_M2=$row['nom'];
		$result->closeCursor();
		$requete="SELECT * from actions WHERE  numero= '$S1'"; // requête proprement dite 
		$result =$bdd->query($requete); // envoi de la requête 
		$row=$result->fetch(); //le résultat revient sous forme d'une matrice
		$nom_S1=$row['nom'];
		$result->closeCursor();
		?>
<!DOCTYPE html>
<html>
<head>
 	<meta charset="utf-8" />
    <title>La Journée du 10 avril 2025</title>
    <link rel="icon" href="images/favicon.png" type="image/jpeg">
	<meta http-equiv="content-language" content="fr" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />  
	<!--[if IE]><link rel="shortcut icon" type="image/x-icon" href="favicon.ico" /><![endif]-->
	<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
	<! c'est l'entête>
	<div id="bloc_page">
		<header>
			<?php if ($type=="prof") {
							?><h1> Bonjour <?php echo $prenomp.' '.$nomp; ?>  
							<h1> Voici la page de <?php echo $prenom.' '.$nom; ?> <?php 
						}
											else {?> <h1> Bonjour <?php echo $prenom.' '.$nom; ?> </h1> <?php } ?>
			<! c'est une barre de navigation>
			<nav>
					<ul>
						<li><a href="index.php">DECONNEXION</a></li>
						<li><a href="descriptif.php">Descriptif</a></li>
						<li>Ma journée</li>
					</ul>
			</nav>	
			<h1> Mon programme de la journée </h1>
			<h3>  Chaque élève doit s'inscrire aux ateliers proposés sur les <strong>4 créneaux </strong> M1, M2, S1 et S2  des</h3>
			<h3> <strong> Un des créneau </strong> pourra être consacré à l'<strong>action 1</strong>: parcours libre de toutes les expositions. </h3>
		</header>
		<! c'est le corps de la page>
		<section>
			<table>
				<tr>
					<td class="colon1">
						<p> 
						<h2> Mon activité en M1 </h2>
							de 9h jusqu'à 10h30
						</p>
					</td>
					<td>
					<?php
					if ($plage=="M1") 
						{ ?>
							<form method = "post" name = "nouvelle_action" action="traitementmodif.php">
								<align="center"> <?php 	echo 'Numero de votre nouvelle action en '.$plage; 
											// on recupere les actions proposées à cette plage et non pleines
											$requete="SELECT * from actions WHERE  M1='M1' AND occupationM1<nombre and numero<400"; // requête proprement dite 
											$result = $bdd->query($requete); // envoi de la requête 
										?> 
								<select name="nouveau" >
									<?php
									while ($row=$result->fetch())
										{ ?> <option value="<?php echo $row['numero']; ?>"> <?php echo $row['numero'].':'.substr($row['nom'],0, 20); ?></option> <?php } 
									$result->closeCursor();
									if ($type=='prof') { ?> <option value="444">444</option> <?php } ?>
								</select>
								<input type="hidden" name="plage" value="M1" />
					</td>
					<td>
					<input type="submit" value="Valider"/>
					</form>
					</td>
					<?php }
					else 
						{ ?>
						<?php echo $M1; ?> 
						</br>
						<?php echo $nom_M1; ?>
						</td>
						<td>
						</td>
						<?php
						} ?>
				</tr>
				<tr>
					<td class="colon1">
						<p> 
							<h2> Mon activité en M2 </h2>
							de 10h30 jusqu'à 12h
						</p>
					</td>
					<td>
					<?php
					if ($plage=="M2") 
						{ ?> 
					<form method = "post" name = "nouvelle_action" action="traitementmodif.php">
						<align="center"> <?php 
											echo 'Numero de votre nouvelle action en '.$plage; 
											// on recupere les actions proposées à cette plage et non pleines
											$requete="SELECT * from actions WHERE  M2='M2' AND occupationM2<nombre and numero<400"; // requête proprement dite 
											$result = $result = $bdd->query($requete);  // envoi de la requête 
										?> 
													<select name="nouveau" >
														<?php while ($row=$result->fetch())
																{ ?> <option value="<?php echo $row['numero']; ?>"> <?php echo $row['numero'].':'.substr($row['nom'],0, 20); ?></option> <?php } 
														$result->closeCursor();
														if ($type=='prof') { ?> <option value="444">444</option> <?php } ?>
													</select>
						<input type="hidden" name="plage" value="M2" />
						<input type="hidden" name="type" value="<?php echo $type ?>" />
						</td>
						<td>
						<input type="submit" value="Valider"/>
						</form>
						</td>
						<?php }
					else 
						{ ?>
						<?php echo $M2; ?> 
						</br>
						<?php echo $nom_M2; ?>
						</td>
						<td>
						</td>
						<?php
						} ?>
				</tr>
				<tr>
					<td class="colon1">
						<p> 
							<h2> Mon activité en S1 </h2>
							de 14h jusqu'à 15h30
						</p>
					</td>
					<td>
					<?php
					if ($plage=="S1") 
						{ ?>
						<form method = "post" name = "nouvelle_action" action="traitementmodif.php">
						<align="center"> <?php 
											echo 'Numero de votre nouvelle action en '.$plage; 
											// on recupere les actions proposées à cette plage et non pleines
											$requete="SELECT * from actions WHERE  S1='S1' AND occupationS1<nombre and numero<400"; // requête proprement dite 
											$result = $result = $bdd->query($requete);  // envoi de la requête 
										?> 
													<select name="nouveau" >
														<?php while ($row=$result->fetch())
																{ ?> <option value="<?php echo $row['numero']; ?>"> <?php echo $row['numero'].':'.substr($row['nom'],0, 20); ?></option> <?php } 
														$result->closeCursor();
														if ($type=='prof') { ?> <option value="444">444</option> <?php } ?>
													</select>
						<input type="hidden" name="plage" value="S1" />
						</td>
						<td>
						<input type="submit" value="Valider"/>
						</form>
						</td>
						<?php }
					else 
						{ ?>
						<?php echo $S1; ?> 
						</br>
						<?php echo $nom_S1; ?>
						</td>
						<td>
						</td>
						<?php
						} ?>
				</tr>
			</table>
		</section>
	</div>
</body>
</html>
