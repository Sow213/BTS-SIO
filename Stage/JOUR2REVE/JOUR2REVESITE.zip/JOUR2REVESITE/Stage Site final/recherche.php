<?php 
session_start();  

if ($_SESSION['classe'] == 'PROF') {
    $nom = $_SESSION['nom'];    
    $prenom = $_SESSION['prenom'];
    $type = 'prof';         
} else {
    header('Location: index.html');
    echo 'raté';
    exit(); // Arrêter l'exécution du script après la redirection
}

// Vérifier si 'mot' est défini dans $_POST
$mot = isset($_POST['mot']) ? htmlspecialchars($_POST['mot']) : '';

// Connexion à MySQL
include('parametreBDD.php');

// Récupération des éléments de la classe
if (!empty($mot)) {
    $requete = "SELECT * from eleves WHERE classe='$mot' OR nom='$mot' OR prenom='$mot'"; 
    $result = $bdd->query($requete);  
} else {
    $result = null; // Aucune recherche si 'mot' est vide
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8" />
    <title>La Journée du 10 avril 2025</title>
    <link rel="icon" href="images/favicon.png" type="image/jpeg">
    <meta http-equiv="content-language" content="fr" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <style>
        /* Général */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        #bloc_page {
            margin: 0 auto;
            width: 90%;
            max-width: 1200px;
        }

        header {
            background-color: #2c3e50;
            color: white;
            padding: 20px;
            text-align: center;
        }

        header h1 {
            margin: 0;
            font-size: 24px;
        }

        nav ul {
            list-style-type: none;
            padding: 0;
        }

        nav ul li {
            display: inline;
            margin: 0 10px;
        }

        nav ul li a {
            color: white;
            text-decoration: none;
        }

        section {
            margin: 20px 0;
        }

        section form {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
        }

        section form input[type="text"] {
            padding: 5px;
            font-size: 16px;
        }

        section form input[type="submit"] {
            padding: 7px 15px;
            background-color: #2980b9;
            color: white;
            border: none;
            cursor: pointer;
        }

        section form input[type="submit"]:hover {
            background-color: #3498db;
        }

        /* Table */
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 12px 20px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #2980b9;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        /* Buttons */
        input[type="submit"] {
            padding: 5px 15px;
            background-color: #16a085;
            color: white;
            border: none;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #1abc9c;
        }
    </style>
</head>
<body>
    <div id="bloc_page">
        <header>
            <h1> Bonjour professeur <?php echo $prenom . ' ' . $nom; ?> </h1>
            <nav>
                <ul>
                    <li><a href="prof.php">Page d'accueil professeur</a></li>
                </ul>
            </nav> 
        </header>

        <section>
            <p> 
                <form method="post" name="recherche" action="recherche.php">
                    Nouvelle recherche: 
                    <input type="text" name="mot" placeholder="Ex : Machin ou 110 ou Pauline" size="30"/>
                    <input type="submit" value="Valider"/>
                </form>
            </p>
        </section>

        <?php if (!empty($mot)) { ?>
            <h1> Voici les résultats de votre recherche pour le mot : <strong><?php echo $mot; ?> </strong></h1>

            <?php if ($result && $result->rowCount() > 0) { ?>
                <table>
                    <thead>
                        <tr>
                            <th>Nom</th>
                            <th>Prénom</th>
                            <th>Classe</th>
                            <th>Action en M1</th>
                            <th>Action en M2</th>
                            <th>Action en S1</th>
                            <th>Action en S2</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch()) { ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['nom']); ?></td>      
                                <td><?php echo htmlspecialchars($row['prenom']); ?></td>
                                <td><?php echo htmlspecialchars($row['classe']); ?></td>
                                <td><?php echo htmlspecialchars($row['M1']); ?></td>      
                                <td><?php echo htmlspecialchars($row['M2']); ?></td>
                                <td><?php echo htmlspecialchars($row['S1']); ?></td>
                                <td><?php echo htmlspecialchars($row['S2']); ?></td>
                                <td>
                                    <?php if ($row['classe'] != 'PROF') { ?>
                                        <form method="post" name="modifier" action="modif_eleve.php">
                                            <input type="hidden" name="nome" value="<?php echo htmlspecialchars($row['nom']); ?>" />
                                            <input type="hidden" name="prenome" value="<?php echo htmlspecialchars($row['prenom']); ?>" />
                                            <input type="hidden" name="mdpe" value="<?php echo htmlspecialchars($row['mdp']); ?>" />
                                            <input type="submit" value="Modifier"/>
                                        </form>
                                    <?php } ?>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            <?php } else { ?>
                <p>Aucun résultat trouvé pour : <strong><?php echo $mot; ?></strong>.</p>
            <?php } 
        } else { ?>
            <p>Aucune recherche effectuée.</p>
        <?php } 

        if ($result) {
            $result->closeCursor();
        }
        ?>
    </div>
</body>
</html>