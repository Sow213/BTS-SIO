<?php session_start(); 
if ($_SESSION['classe']=='PROF') {
    $nom = $_SESSION['nom'];    
    $prenom = $_SESSION['prenom'];
    $type='prof';        
} else {
    header('Location: index.html');
    exit();
}

// On récupère les données du formulaire
$numero = isset($_POST['numero']) ? $_POST['numero'] : 0;

// Connexion à la base de données
include('parametreBDD.php');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>La Journée du 10 avril 2025</title>
    <link rel="icon" href="images/favicon.png" type="image/jpeg">
    <link rel="stylesheet" type="text/css" href="style2.css">
    <nav>
        <ul style="list-style-type: none; display: flex; justify-content: center; background-color: #2C3E50; padding: 10px;">
            <li><a href="index.php" style="color: white; text-decoration: none; padding: 10px 20px;">Accueil</a></li>
            <li><a href="connexion.php" style="color: white; text-decoration: none; padding: 10px 20px;">Connexion</a></li>
            <li><a href="ateliers.php" style="color: white; text-decoration: none; padding: 10px 20px;">Ateliers</a></li>
            <li><a href="expositions.php" style="color: white; text-decoration: none; padding: 10px 20px;">Expositions</a></li>
            <li><a href="prof.php" style="color: white; text-decoration: none; padding: 10px 20px;">Page d'accueil professeur</a></li>
        </ul>
    </nav>
    <meta http-equiv="content-language" content="fr" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />  
    <link rel="stylesheet" type="text/css" href="style2.css">

    <style>
        @media print {
            body * {
                visibility: hidden;
            }
            #print-section, #print-section * {
                visibility: visible;
            }
            #print-section {
                position: absolute;
                top: 0;
                left: 0;
            }
            table {
                width: 100%;
                border: 2px solid #000;
                font-size: 18px; /* Agrandir le texte du tableau */
            }
            th, td {
                padding: 15px; /* Augmenter l'espace des cellules */
                text-align: center;
            }
            .print-button {
                visibility: hidden; /* Cacher le bouton "Imprimer" à l'impression */
            }
        }

        /* Amélioration du bouton "Imprimer" */
        .print-button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .print-button:hover {
            background-color: #0056b3;
        }

        .print-button:focus {
            outline: none;
        }
    </style>
</head>
<body>
    <header>
        <h1>Bonjour professeur <?php echo $prenom.' '.$nom; ?></h1>
    </header>
    <div id="bloc_page">
        <section>
            <form method="post" name="nouvelle_action" action="fiche_atelier.php">
                <align="center"> 
                    <?php 
                    echo 'Code';
                    // On récupère les actions proposées 
                    $requete = "SELECT * FROM actions ORDER BY numero"; 
                    $result = $bdd->query($requete); 
                    ?> 
                    <select name="numero">
                        <option value="0">Tous les ateliers</option>
                        <?php while ($row = $result->fetch()) { ?> 
                            <option value="<?php echo $row['numero']; ?>" <?php if ($row['numero'] == $numero) { ?> selected="selected" <?php } ?>> 
                                <?php echo $row['code'] . ' - ' . $row['nom']; ?>
                            </option> 
                        <?php } ?>
                    </select>
                    <input type="hidden" name="nom" value="<?php echo $nom ?>" />
                    <input type="hidden" name="prenom" value="<?php echo $prenom ?>" />
                    <input type="submit" value="Valider"/>
                </align>
            </form>
        </section>
        
        <?php 
        // Liste des créneaux à afficher
        $creneaux = ['M1', 'M2', 'S1', 'S2'];

        if ($numero == 0) {  
            // Afficher tous les ateliers
            $requete = "SELECT * FROM actions WHERE nombre > 0 AND nombre < 1000 ORDER BY numero";    
            $result = $bdd->query($requete); 
            while ($row2 = $result->fetch()) { 
                $nom_atelier = $row2['nom'];
                $nombre = $row2['nombre'];
                $numero2 = $row2['numero'];
                ?> 
                <!-- Section à imprimer -->
                <div id="print-section">
                    <h2>Pour l'atelier : <?php echo $numero2.' / '.$nom_atelier; ?></h2>
                    <h3>Voici les élèves inscrits à l'atelier : <?php echo $row2['code']; ?></h3>
                    <table border="1">
                        <tr>
                            <th>Créneau</th>
                            <th>Inscrits</th>
                            <th>Nom | Prénom | Classe</th>
                        </tr>
                        <?php 
                        foreach ($creneaux as $creneau) {
                            // Compter le nombre d'inscrits pour ce créneau
                            $requete2 = "SELECT COUNT(*) as nb_inscrits FROM eleves WHERE $creneau = $numero2"; 
                            $result2 = $bdd->query($requete2); 
                            $row3 = $result2->fetch();
                            $nb_inscrits = $row3['nb_inscrits']; // Nombre d'inscrits
                            $result2->closeCursor();

                            // Récupérer la liste des inscrits
                            $requete3 = "SELECT * FROM eleves WHERE $creneau = $numero2"; 
                            $result3 = $bdd->query($requete3); 
                            ?>
                            <tr>
                                <td><?php echo $creneau; ?></td>
                                <td>
                                    <strong><?php echo $nb_inscrits . '/' . $nombre; ?></strong>
                                </td>
                                <td>
                                    <?php
                                    $i = 0;
                                    while ($row4 = $result3->fetch()) {
                                        $i = $i + 1; 
                                        echo $i . '--' . $row4['nom'] . '  ' . $row4['prenom'] . ' ' . $row4['classe']; ?> </br> <?php 
                                    }
                                    if ($i == 0) {
                                        echo "Aucun inscrit";
                                    }
                                    $result3->closeCursor();
                                    ?>  
                                </td>
                            </tr>
                            <?php 
                        }
                        ?>
                    </table>
                </div>
                <!-- Fin de la section à imprimer -->
                <button class="print-button" onclick="window.print();">Imprimer cet atelier</button>
                </br>
                <?php 
            }
            $result->closeCursor();                
        } else {    
            // Afficher un atelier spécifique
            $requete = "SELECT * FROM actions WHERE numero = '$numero'"; 
            $result = $bdd->query($requete); 
            $row = $result->fetch();
            $nom_atelier = $row['nom'];
            $nombre = $row['nombre'];
            $result->closeCursor();
            ?>
            <h1>Voici le remplissage de l'atelier:</h1>
            <h2><?php echo $numero . ' : ' . $nom_atelier; ?></h2>
            <h1>Voici les élèves inscrits à l'atelier : <?php echo $row['code']; ?></h1>
            <!-- Section à imprimer -->
            <div id="print-section">
                <h2>Nom de l'atelier : <?php echo $nom_atelier; ?></h2> <!-- Afficher le nom de l'atelier avant le tableau -->
                <table border="1">
                    <tr>
                        <th>Créneau</th>
                        <th>Inscrits</th>
                        <th>Nom | Prénom | Classe</th>
                    </tr>
                    <?php 
                    foreach ($creneaux as $creneau) {
                        // Compter le nombre d'inscrits pour ce créneau
                        $requete2 = "SELECT COUNT(*) as nb_inscrits FROM eleves WHERE $creneau = $numero"; 
                        $result2 = $bdd->query($requete2); 
                        $row3 = $result2->fetch();
                        $nb_inscrits = $row3['nb_inscrits']; // Nombre d'inscrits
                        $result2->closeCursor();

                        // Récupérer la liste des inscrits
                        $requete3 = "SELECT * FROM eleves WHERE $creneau = $numero"; 
                        $result3 = $bdd->query($requete3); 
                        ?>
                        <tr>
                            <td><?php echo $creneau; ?></td>
                            <td>
                                <strong><?php echo $nb_inscrits . '/' . $nombre; ?></strong>
                            </td>
                            <td>
                                <?php
                                $i = 0;
                                while ($row4 = $result3->fetch()) {
                                    $i = $i + 1; 
                                    echo $i . '--' . $row4['nom'] . '  ' . $row4['prenom'] . ' ' . $row4['classe']; ?> </br> <?php 
                                }
                                if ($i == 0) {
                                    echo "Aucun inscrit";
                                }
                                $result3->closeCursor();
                                ?>  
                            </td>
                        </tr>
                        <?php 
                    }
                    ?>
                </table>
            </div>
            <!-- Fin de la section à imprimer -->
            <button class="print-button" onclick="window.print();">Imprimer cet atelier</button>
        <?php
        }
        ?>
    </div>
    
    <!-- Footer -->
    <footer class="bg-dark text-center text-white py-3 mt-5">
        © 2025 La Journée du 10 Avril. Tous droits réservés.
        <p>LYCEE GENERAL ET TECHNOLOGIQUE HENRI MATISSE 
            <br> Adresse : 49 avenue du Comminges 31270 CUGNAUX 
            <br> Téléphone : +33 5 61 72 75 40</p>
    </footer>
</body>
</html>
