<?php
session_start();

session_start(); 
// Connexion à MySQL
include('parametreBDD.php');
// fin de la partie connexion

$LOGIN_MAGRET = $_POST['LOGIN_MAGRET'];
$MDP_MAGRET = $_POST['MDP_MAGRET']; 

$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Vérification de la connexion via formulaire POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $login = $_POST['login'];
    $motDePasse = $_POST['motDePasse'];

    // Requête pour récupérer les informations de l'utilisateur
    $query = "SELECT * FROM utilisateurs WHERE nomUtilisateur = '$login' AND role = 'gestionnaire'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($motDePasse, $user['motDePasse'])) {
            $_SESSION['role'] = 'gestionnaire';
            $_SESSION['nomUtilisateur'] = $user['nomUtilisateur'];
            header("Location: tableau_de_bord.php");
            exit();
        } else {
            $errorMessage = "Mot de passe incorrect.";
        }
    } else {
        $errorMessage = "Identifiants incorrects.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - Gestionnaire</title>
</head>
<body>

<h2>Connexion en mode Gestionnaire</h2>

<form method="POST">
    <label for="login">Login: </label>
    <input type="text" id="login" name="login" required><br><br>
    <label for="motDePasse">Mot de passe: </label>
    <input type="password" id="motDePasse" name="motDePasse" required><br><br>
    <input type="submit" value="Se connecter">
</form>

<?php if (isset($errorMessage)) { echo "<p style='color:red;'>$errorMessage</p>"; } ?>

</body>
</html>
