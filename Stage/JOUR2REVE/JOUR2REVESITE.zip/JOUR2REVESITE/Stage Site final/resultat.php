<?php 
session_start(); 
// Connexion à MySQL
include('parametreBDD.php');
// fin de la partie connexion

$LOGIN_MAGRET = $_POST['LOGIN_MAGRET'];
$MDP_MAGRET = $_POST['MDP_MAGRET'];	
	
// On teste si c'est l'admin
// if ($LOGIN_MAGRET == "admin" AND $MDP_MAGRET == "") 
// {header('Location: admin.html');}
// else 
// { 
// On récupère l'identité de l'élève à partir de ces identifiants Magret
$requete = "SELECT * FROM eleves WHERE login = :login AND mdp = :mdp"; // requête préparée
$stmt = $bdd->prepare($requete); // préparation de la requête
$stmt->bindParam(':login', $LOGIN_MAGRET);
$stmt->bindParam(':mdp', $MDP_MAGRET);
$stmt->execute(); // exécution de la requête

$row = $stmt->fetch(); // le résultat revient sous forme d'une matrice

if ($row) { // Vérifie si la requête a retourné des résultats
    $_SESSION['nom'] = $row['nom'];
    $_SESSION['prenom'] = $row['prenom'];
    $_SESSION['mdp'] = $row['mdp'];
    $_SESSION['classe'] = $row['classe'];

    if ($_SESSION['classe'] == 'PROF') {
        header('Location: prof.php');
    } else {
        if ($_SESSION['nom'] != '') {
            header('Location: eleve.php');	
        } else { 
            echo 'Vous n\'avez pas entré un identifiant ou un mot de passe correct';
            ?> <li><a href="index.php">Page d'accueil</a></li> <?php
        }
    }
} else {
    echo 'Identifiants incorrects';
    ?> <li><a href="index.php">Page d\'accueil</a></li> <?php
}

$stmt->closeCursor();
?>
