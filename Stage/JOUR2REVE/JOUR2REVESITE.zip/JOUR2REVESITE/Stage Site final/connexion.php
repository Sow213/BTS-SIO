<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="robots" content="noindex" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - Journée du 10 avril 2025</title>
    <link rel="icon" href="images/favicon.png" type="image/jpeg">
    <link rel="stylesheet" type="text/css" href="bootstrap.css">

    <!-- Menu -->
 <nav>
    <ul style="list-style-type: none; display: flex; justify-content: center; background-color: #2C3E50; padding: 10px;">
        <li><a href="index.php" style="color: white; text-decoration: none; padding: 10px 20px;">Accueil</a></li>
        <li><a href="connexion.php" style="color: white; text-decoration: none; padding: 10px 20px;">Connexion</a></li>
        <li><a href="ateliers.php" style="color: white; text-decoration: none; padding: 10px 20px;">Ateliers</a></li>
        <li><a href="expositions.php" style="color: white; text-decoration: none; padding: 10px 20px;">Expositions</a></li>
    </ul>
</nav>

    <style>
        body {
            background: url('https://cdn.pixabay.com/photo/2017/08/24/03/41/starry-sky-2675322_1280.jpg') center/cover fixed;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            color: #333;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            background: rgba(255, 255, 255, 0.9);
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            padding: 30px;
        }
        h1 {
            text-align: center;
            color: #2C3E50;
        }
        p {
            line-height: 1.6;
            text-align: center;
            margin-bottom: 20px;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        input[type="submit"] {
            background-color: #5D6D7E;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }
        input[type="submit"]:hover {
            background-color: #34495E;
        }
        footer {
            text-align: center;
            margin-top: 30px;
            padding: 10px 0;
            background: rgba(0, 0, 0, 0.6);
            color: #fff;
            border-radius: 0 0 10px 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Connexion à l'espace Magret</h1>
        <p>Entrez votre identifiant et votre mot de passe Magret</p>
        <p>Ce sont ceux utilisés au lycée pour ouvrir une session sur les ordinateurs.</p>

        <form method="post" name="interrogation_magret_puis_reponse" action="resultat.php">
            <label for="LOGIN_MAGRET">Identifiant Magret:</label>
            <input type="text" id="LOGIN_MAGRET" name="LOGIN_MAGRET" required />

            <label for="MDP_MAGRET">Mot de passe Magret:</label>
            <input type="password" id="MDP_MAGRET" name="MDP_MAGRET" required />

            <input type="submit" value="Envoyer" />
        </form>
    </div>
    
    <!-- Footer -->
    <footer class="bg-dark text-center text-white py-3 mt-5">
		© 2025 La Journée du 10 Avril. Tous droits réservés. 
        <p>LYCEE GENERAL ET TECHNOLOGIQUE HENRI MATISSE 
            <br> Adresse : 49 avenue du Comminges 31270 CUGNAUX 
            <br> Téléphone : +33 5 61 72 75 40</p>
</footer>
</body>
</html>
