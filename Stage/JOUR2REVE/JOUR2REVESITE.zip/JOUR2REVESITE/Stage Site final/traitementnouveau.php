<?php
session_start();

// Connexion à la base de données
include('parametreBDD.php');

// Vérification du rôle de l'utilisateur
if ($_SESSION['classe'] != 'PROF') {
    header('Location: index.html');
    exit();
}

// Récupération des informations du formulaire
$nome = htmlspecialchars($_POST['nome']);
$prenome = htmlspecialchars($_POST['prenome']);
$mdpe = htmlspecialchars($_POST['mdpe']);
$classe = htmlspecialchars($_POST['classe']);
$login = htmlspecialchars($_POST['login']);
$mdp = htmlspecialchars($_POST['mdp']);

// Vérification si l'élève existe déjà
$requete = "SELECT * FROM eleves WHERE nom = :nome AND prenom = :prenome";
$stmt = $bdd->prepare($requete);
$stmt->execute([':nome' => $nome, ':prenome' => $prenome]);
$existingStudent = $stmt->fetch();
$stmt->closeCursor();

// Vérification du mot de passe
$requeteMdp = "SELECT mdp FROM eleves WHERE nom = 'PROFTEST'";
$stmtMdp = $bdd->query($requeteMdp);
$row = $stmtMdp->fetch();
$stmtMdp->closeCursor();

if ($mdp2 == $mdpe) {
    if (!$existingStudent) {
        // Insertion du nouvel élève
        $requeteInsert = "INSERT INTO eleves (classe, nom, prenom, login, mdp, M1, M2, S1) 
                          VALUES (:classe, :nome, :prenome, :login, :mdp, '0', '0', '0')";
        $stmtInsert = $bdd->prepare($requeteInsert);
        $stmtInsert->execute([
            ':classe' => $classe,
            ':nome' => $nome,
            ':prenome' => $prenome,
            ':login' => $login,
            ':mdp' => $mdp
        ]);
        $stmtInsert->closeCursor();

        echo "<h2>L'élève $nome $prenome a bien été créé dans la classe $classe.</h2>";
        echo '<form method="post" name="atelier" action="prof.php">
                <input type="submit" value="Retour page professeur"/>
              </form>';
    } else {
        echo "<h2>$nome $prenome existe déjà !</h2>";

        // Affichage des informations de l'élève existant
        echo '<table>
                <tr>
                    <td>Nom : ' . $existingStudent['nom'] . '</td>
                    <td>Prénom : ' . $existingStudent['prenom'] . '</td>
                    <td>Classe : ' . $existingStudent['classe'] . '</td>
                    <td>
                        <form method="post" name="atelier" action="nouveau.php">
                            <input type="submit" value="Retour création de compte"/>
                        </form>
                    </td>
                </tr>
              </table>';
    }
} else {
    echo "<h1>MAUVAIS MOT DE PASSE</h1>";
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>

<title>La Journée du 10 avril 2025</title>
    <link rel="icon" href="images/favicon.png" type="image/jpeg">
    <link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
	    <!-- Footer -->
    <footer class="bg-dark text-center text-white py-3 mt-5">
        © 2025 La Journée du 10 Avril. Tous droits réservés.
        <p>LYCEE GENERAL ET TECHNOLOGIQUE HENRI MATISSE 
            <br> Adresse : 49 avenue du Comminges 31270 CUGNAUX 
            <br> Téléphone : +33 5 61 72 75 40</p>
    </footer>
</body>
</html>
