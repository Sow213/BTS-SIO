<?php session_start();  
// appeler descriptif.php avec nom="rien" et prenom"rien"
$_SESSION['nom'] = "rien";
$_SESSION['prenom']="rien";
$_SESSION['classe']="";
header('Location: ateliers.php');
?>