<!DOCTYPE html>
<html>
<head>
  	<meta charset="utf-8" />
	<meta http-equiv="content-language" content="fr" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />  
    <title>La Journée du 10 avril 2025</title>
    <link rel="icon" href="images/favicon.png" type="image/jpeg">
	<!--[if IE]><link rel="shortcut icon" type="image/x-icon" href="favicon.ico" /><![endif]-->
	<link rel="stylesheet" type="text/css" href="style2.css" />	
</head>

<body>
	<! c'est l'entête>
	<div id="bloc_page">
		<header>
			<h1> La journée du 12 avril </h1>
			<! c'est une barre de navigation>
			<nav>
					<ul>
						<li><a href="index.php">Page d'accueil</a></li>
						<li><a href="livre.pdf">Télécharger le livre complet</a></li>
					</ul>
			</nav>	
		</header>
		<! c'est le corps de la page>
		<section>
			<table>
				<tr>
					<td>		
						<p align="center"> 
							Planning:
						</p>
						<p>
							<img src="images/planning.jpg" class="imageflottante" alt="Planning"/>
						</p>
					</td>
					<td>
						<p> 
							<h2> Cela commencera par : </h2>
							<ul>
								<li><a href="surprise.php">Une surprise</a></li>
							</ul>
							<h2> Chaque élève doit s'inscrire aux ateliers proposés sur les 3 créneaux M1, M2, S1 et S2.</h2>
							<ul>
								<li><a href="traitement-action.php">Voir les ateliers proposés</a></li>
							</ul>
							<h2>Une des activités proposées (Action 1) pourra être le parcours libre de la vingtaine d'expositions présentes dans l'établissement.</h2>
							<ul>
								<li><a href="expositions.php">Voir les expositions proposées</a></li>
							</ul>
							<h2> Le journée se terminera par :</h2>
							<ul>
								<li><a href="bal.php">Un bal</a></li>
							</ul>
							<h2> Maintenant que tout est clair, allez choisir vos ateliers : </h2>
							<ul>
								<li><a href="connexion.php">Connexion et inscription</a></li>
							</ul>
						</p>
					</td>
				</tr>
			</table>
		</section>
	</div>
</body>
</html>
