<?php session_start(); 	
	// Connection à mysql
	include('parametreBDD.php');
	// fin de la partie connexion
	// on récupère les infos
	if ($_SESSION['classe']=='PROF') 
			{
				$nom = $_POST['nome'];	
				$prenom = $_POST['prenome'];
				$mdp = $_POST['mdpe'];
			} 
			else 
			{header('Location: index.html');}
	// on récupère les numeros des actions avant modif
	$requete="SELECT * from eleves WHERE  prenom= '$prenom'  AND nom = '$nom' AND mdp='$mdp'" ; // requête proprement dite 
	$result = $bdd->query($requete); // envoi de la requête 
		$row=$result->fetch(); //le résultat revient sous forme d'une matrice
		$M1=$row['M1'];
		$M2=$row['M2'];
		$S1=$row['S1'];
		$S1=$row['S2'];
	$result->closeCursor();
	// mettre 444 dans les 4 ateliers
		
		$requete2="UPDATE eleves SET M1=444 WHERE prenom= '$prenom'  AND nom = '$nom' AND mdp='$mdp'";
		$result2 =$bdd->query($requete2);
		$result2->closeCursor();
		$requete2="UPDATE eleves SET M2=444 WHERE prenom= '$prenom'  AND nom = '$nom' AND mdp='$mdp'";
		$result2 =$bdd->query($requete2);  // envoi de la requête
		$result2->closeCursor();
		$requete2="UPDATE eleves SET S1=444 WHERE prenom= '$prenom'  AND nom = '$nom' AND mdp='$mdp' ";
		$result2 =$bdd->query($requete2);  // envoi de la requête
		$result2->closeCursor();
		$requete2="UPDATE eleves SET S2=444 WHERE prenom= '$prenom'  AND nom = '$nom' AND mdp='$mdp' ";
		$result2 =$bdd->query($requete2);  // envoi de la requête
		$result2->closeCursor();
		header('Location: problemes.php');
	
?>
