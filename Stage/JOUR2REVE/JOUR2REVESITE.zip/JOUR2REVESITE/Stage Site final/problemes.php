<?php 
session_start(); 

if ($_SESSION['classe'] == 'PROF') {
    $nom = $_SESSION['nom'];
    $prenom = $_SESSION['prenom'];
    $type = 'prof';
} else {
    header('Location: index.php');
    exit;
}

// Connexion à MySQL
include('parametreBDD.php');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="content-language" content="fr" />
    <title>La Journée du 10 avril 2025</title>
    <link rel="icon" href="images/favicon.png" type="image/jpeg">
    <link rel="stylesheet" href="bootstrap.css">
    <link rel="stylesheet" href="style2.css">

</head>
<body>
    <div id="bloc_page">
        <header>
            <h1>Bonjour professeur <?php echo htmlspecialchars($prenom) . ' ' . htmlspecialchars($nom); ?></h1>
<!-- Menu -->
            <nav>
                <ul style="list-style-type: none; display: flex; justify-content: center; background-color: #2C3E50; padding: 10px;">
                    <li><a href="index.php" style="color: white; text-decoration: none; padding: 10px 20px;">Accueil</a></li>
                    <li><a href="connexion.php" style="color: white; text-decoration: none; padding: 10px 20px;">Connexion</a></li>
                    <li><a href="ateliers.php" style="color: white; text-decoration: none; padding: 10px 20px;">Ateliers</a></li>
                    <li><a href="expositions.php" style="color: white; text-decoration: none; padding: 10px 20px;">Expositions</a></li>
                    <li><a href="prof.php" style="color: white; text-decoration: none; padding: 10px 20px;">Page d'accueil professeur</a></li>
                </ul>
            </nav>  
        </header>

        <!-- Liste déroulante pour filtrer par classe -->
        <form method="GET" action="">
            <label for="classe">Sélectionnez une classe :</label>
            <select name="classe" id="classe">
                <option value="">Toutes les classes</option>
                <?php
                // Récupérer les classes depuis la base de données
                $requeteClasses = "SELECT DISTINCT classe FROM eleves WHERE classe != 'PROF' AND classe != 'rien'";
                $resultClasses = $bdd->query($requeteClasses);
                while ($rowClass = $resultClasses->fetch()) {
                    echo "<option value='" . htmlspecialchars($rowClass['classe']) . "'>" . htmlspecialchars($rowClass['classe']) . "</option>";
                }
                ?>
            </select>
            <input type="submit" value="Filtrer">
        </form>

        <table>
            <?php
            $selectedClasse = isset($_GET['classe']) ? $_GET['classe'] : '';

            // Calcul des inscriptions élèves en fonction de la classe sélectionnée
            $requete = "SELECT * FROM eleves WHERE classe != 'PROF' AND classe != 'rien'";
            if ($selectedClasse) {
                $requete .= " AND classe = '$selectedClasse'";
            }
            $result = $bdd->query($requete);

            $kt = 0; $it = 0; $jt = 0; $mt = 0; $st = 0;
            while ($row2 = $result->fetch()) {
                $M1 = $row2['M1'];
                $M2 = $row2['M2'];
                $S1 = $row2['S1'];
                $S2 = $row2['S2'];
                $i = ($M1 == 0) + ($M2 == 0) + ($S1 == 0) + ($S2 == 0);
                if ($i > 0) $mt++;
                $kt += ($S1 == 0 || $S2 == 0);
                $jt += ($M2 == 0);
                $it += ($M1 == 0);
                $st += ($S2 == 0);
            }
            $result->closeCursor();

            // Calcul des places restantes
            $l1 = 0; $l2 = 0; $l3 = 0; $l4 = 0;
            $requete = "SELECT * FROM actions WHERE nombre > 0 AND nombre < 1000";
            $result = $bdd->query($requete);

            while ($row2 = $result->fetch()) {
                $l1 += ($row2['M1'] == 'M1') ? $row2['nombre'] - $row2['occupationM1'] : 0;
                $l2 += ($row2['M2'] == 'M2') ? $row2['nombre'] - $row2['occupationM2'] : 0;
                $l3 += ($row2['S1'] == 'S1') ? $row2['nombre'] - $row2['occupationS1'] : 0;
                $l4 += ($row2['S2'] == 'S2') ? $row2['nombre'] - $row2['occupationS2'] : 0;
            }
            $result->closeCursor();
            ?>

            <tr>
                <td class="ligne1" colspan="6">
                    <h2>
                        Nombre de plages non remplies : <?php echo $kt + $it + $jt + $st; ?> dont :
                        <?php echo $it; ?> en M1, <?php echo $jt; ?> en M2, <?php echo $kt; ?> en S1 et <?php echo $st; ?> en S2
                        (cela concerne <?php echo $mt; ?> élèves).
                    </h2>
                    <h2>
                        Pour <?php echo $l1 + $l2 + $l3 + $l4; ?> places libres dont :
                        <?php echo $l1; ?> en M1, <?php echo $l2; ?> en M2, <?php echo $l3; ?> en S1, et <?php echo $l4; ?> en S2.
                    </h2>
                </td>
            </tr>
            <tr>
                <td class="ligne1" colspan="6">
                    <h1>Les élèves insuffisamment inscrits sont :</h1>
                </td>
            </tr>

            <?php
            // Affichage des élèves insuffisamment inscrits
            $requete2 = "SELECT * FROM eleves WHERE classe != 'PROF' AND classe != 'rien'";
            if ($selectedClasse) {
                $requete2 .= " AND classe = '$selectedClasse'";
            }
            $requete2 .= " ORDER BY classe";
            $result2 = $bdd->query($requete2);

            $n = 0;
            $currentClasse = '';
            while ($row2 = $result2->fetch()) {
                $M1 = $row2['M1'];
                $M2 = $row2['M2'];
                $S1 = $row2['S1'];
                $S2 = $row2['S2'];
                $classe = $row2['classe'];
                $i = ($M1 == 0) + ($M2 == 0) + ($S1 == 0) + ($S2 == 0);

                if ($i > 0) {
                    if ($currentClasse != $classe) {
                        $currentClasse = $classe;
                        ?>
                        <tr>
                            <td colspan="6">
                                <h2>Pour la classe <?php echo htmlspecialchars($classe); ?></h2>
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                    <tr>
                        <td><?php echo ++$n; ?></td>
                        <td><?php echo htmlspecialchars($classe) . ' ' . htmlspecialchars($row2['nom']) . ' ' . htmlspecialchars($row2['prenom']); ?></td>
                        <td class="ligne2">
                            en M1 : <strong class="highlight"><?php echo $M1; ?></strong>,
                            en M2 : <strong class="highlight"><?php echo $M2; ?></strong>,
                            en S1 : <strong class="highlight"><?php echo $S1; ?></strong>,
                            en S2 : <strong class="highlight"><?php echo $S2; ?></strong>
                        </td>
                        <td>
                            <form method="post" action="dispenser.php">
                                <input type="hidden" name="nome" value="<?php echo htmlspecialchars($row2['nom']); ?>" />
                                <input type="hidden" name="prenome" value="<?php echo htmlspecialchars($row2['prenom']); ?>" />
                                <input type="submit" value="Dispenser" />
                            </form>
                        </td>
                        <td>
                            <form method="post" action="modif_eleve.php">
                                <input type="hidden" name="nome" value="<?php echo htmlspecialchars($row2['nom']); ?>" />
                                <input type="hidden" name="prenome" value="<?php echo htmlspecialchars($row2['prenom']); ?>" />
                                <input type="submit" value="Modifier" />
                            </form>
                        </td>
                    </tr>
                    <?php
                }
            }
            $result2->closeCursor();
            ?>
        </table>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-center text-white py-3 mt-5">
        © 2025 La Journée du 10 Avril. Tous droits réservés.
        <p>
            LYCEE GENERAL ET TECHNOLOGIQUE HENRI MATISSE<br>
            Adresse : 49 avenue du Comminges 31270 CUGNAUX<br>
            Téléphone : +33 5 61 72 75 40
        </p>
    </footer>
</body>
</html>
